import cv2
import numpy as np
import pywt
from scipy.stats import kurtosis, skew
import math

def imread(image_path):

    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise ValueError(f"Khong the doc anh: {image_path}")
    return img

def extract_features(img):

    coeffs2 = pywt.dwt2(img, 'haar')
    _, (LH, HL, HH) = coeffs2  

    feature_vector = []

  
    for sub_band in [LH, HL, HH]:
        sub_band_flat = sub_band.flatten()

        features = [
            np.mean(sub_band_flat),  
            np.var(sub_band_flat),   
            skew(sub_band_flat),     
            kurtosis(sub_band_flat)  
        ]
        feature_vector.extend(features)

    return np.array(feature_vector)

def euclidean_distance(vector1, vector2):
  
    if len(vector1) != len(vector2):
        raise ValueError("Do dai 2 vector khong khop")
    return math.sqrt(sum((a - b) ** 2 for a, b in zip(vector1, vector2)))

def compare_images(img1_path, img2_path):

    img1 = imread(img1_path)
    img2 = imread(img2_path)

    features1 = extract_features(img1)
    features2 = extract_features(img2)

    print(f"\nVector dac trung anh ({img1_path}): {features1}")
    print(f"\nVector dac trung anh({img2_path}): {features2}")

 
    distance = euclidean_distance(features1, features2)
    print(f"\nKhoang cach: {distance}")

    threshold = 0.4
    if distance > threshold:
        print("\n Anh co the bi giau tin")
    else:
        print("\nAnh sach!")

if __name__ == "__main__":

    compare_images("input_image.jpg", "stego.jpg")