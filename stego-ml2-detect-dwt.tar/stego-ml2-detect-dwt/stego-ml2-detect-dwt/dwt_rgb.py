import os
import cv2
import numpy as np
import pywt
import math

def text_to_bits(text):
    return ''.join(format(ord(c), '08b') for c in text)


def calculate_psnr(img1, img2):
    mse = np.mean((img1.astype("float") - img2.astype("float")) ** 2)
    if mse == 0:
        return float('inf')
    return 20 * math.log10(255.0 / math.sqrt(mse))

def embed_message(image_path, message, output_path):
    img = cv2.imread(image_path)
    if img is None:
        print(f"Khong doc duoc anh: {image_path}")
        return
    h, w = img.shape[:2]
    img = img[:h - h % 2, :w - w % 2]

    b_channel = img[:, :, 0].astype(np.float32)
    coeffs = pywt.dwt2(b_channel, 'haar')
    cA, (cH, cV, cD) = coeffs

    bits = text_to_bits(message)
    cD_flat = cD.flatten()
    if len(bits) > len(cD_flat):
        print(f"Khong du cho giau tin cho {image_path}")
        return

    for i in range(len(bits)):
        bit = int(bits[i])
        cD_flat[i] = np.round(cD_flat[i])
        if bit == 1:
            cD_flat[i] += 1.0
        else:
            cD_flat[i] -= 1.0
    cD_mod = cD_flat.reshape(cD.shape)
    coeffs_mod = (cA, (cH, cV, cD_mod))
    b_stego = pywt.idwt2(coeffs_mod, 'haar')
    b_stego = np.clip(b_stego, 0, 255).astype(np.uint8)

    stego_img = img.copy()
    stego_img[:, :, 0] = b_stego

    cv2.imwrite(output_path, stego_img, [cv2.IMWRITE_PNG_COMPRESSION, 0])
    psnr = calculate_psnr(img, stego_img)
    print(f" {os.path.basename(image_path)} → PSNR: {psnr:.2f} dB")

def embed_all(input_dir, output_dir, message="Hello PTIT"):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    for fname in os.listdir(input_dir):
        if fname.lower().endswith((".jpg", ".jpeg", ".png", ".bmp")):
            input_path = os.path.join(input_dir, fname)
            output_path = os.path.join(output_dir, fname)
            embed_message(input_path, message, output_path)

if __name__ == "__main__":
    embed_all("input_images", "stego_images", message="Hello PTIT!")
