import os
import cv2
import numpy as np
import pywt
from scipy.stats import entropy as calc_entropy
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report

def resize_image(img, max_size=256):
    h, w = img.shape
    if h > max_size or w > max_size:
        scale = max_size / max(h, w)
        img = cv2.resize(img, (int(w * scale), int(h * scale)))
    return img

def extract_stats(sub_band):
    flat = sub_band.flatten()
    energy = np.sum(flat**2)
    std = np.std(flat)
    hist, _ = np.histogram(flat, bins=32, density=True)
    hist = hist[hist > 0]
    ent = calc_entropy(hist)
    return [energy, std, ent]

def extract_features_dwt(image_path):
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise Exception(f"Khong the doc anh: {image_path}")
    img = resize_image(img)
    coeffs2 = pywt.dwt2(img, 'haar')
    _, (LH, HL, HH) = coeffs2

    features = []
    for band in [LH, HL, HH]:
        features.extend(extract_stats(band))
    return features

def load_dataset(clean_folder, stego_folder):
    X, y = [], []
    print("Dang load du lieu...")
    for label, folder in zip([0, 1], [clean_folder, stego_folder]):
        for fname in os.listdir(folder):
            path = os.path.join(folder, fname)
            try:
                feat = extract_features_dwt(path)
                X.append(feat)
                y.append(label)
            except Exception as e:
                print(f"Bo qua {fname} - Loi: {e}")
    return np.array(X), np.array(y)

def train_and_evaluate(X, y):
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    print("\nBao cao danh gia mo hinh:")
    print(classification_report(y_test, y_pred))
    return model, scaler

def check_image(image_path, model, scaler):
    try:
        features = extract_features_dwt(image_path)
        features_scaled = scaler.transform([features])
        pred = model.predict(features_scaled)[0]
        print(f"\nKet qua du doan cho {image_path}: {'Giau tin' if pred == 1 else 'Sach'}")
    except Exception as e:
        print(f"Loi khi du doan: {e}")

if __name__ == "__main__":
    clean_dir = "input_images"
    stego_dir = "stego_images"
    check_path = "check.jpg"

    X, y = load_dataset(clean_dir, stego_dir)
    if len(X) == 0:
        print("Khong co du lieu.")
        exit()

    model, scaler = train_and_evaluate(X, y)
    check_image(check_path, model, scaler)
